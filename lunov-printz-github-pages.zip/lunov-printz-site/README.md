# Lunovaré Printz — GitHub Pages Website

**Premium Custom Sublimation Printing & Apparel · Malaysia**

> A production-ready, single-page landing website for Lunovaré Printz.  
> Built with vanilla HTML, CSS, and JavaScript — no frameworks, no build tools, no dependencies to install.

---

## 🚀 Quick Deploy to GitHub Pages

Follow these steps to publish your website live in under 5 minutes.

### Step 1 — Create a GitHub Repository

1. Go to [github.com](https://github.com) and sign in (or create a free account).
2. Click the **"+"** icon → **"New repository"**.
3. Name it anything you like, e.g. `lunovareprintz` or `website`.
4. Set it to **Public** (required for free GitHub Pages).
5. Click **"Create repository"**.

### Step 2 — Upload the Files

**Option A — Upload via GitHub website (easiest):**

1. Open your new repository.
2. Click **"uploading an existing file"** or **"Add file" → "Upload files"**.
3. Drag and drop **all 5 files** from this folder:
   - `index.html`
   - `style.css`
   - `script.js`
   - `favicon.svg`
   - `README.md`
4. Scroll down, write a commit message (e.g. `Initial upload`), and click **"Commit changes"**.

**Option B — Git command line:**

```bash
git init
git add .
git commit -m "Initial upload"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

### Step 3 — Enable GitHub Pages

1. In your repository, click **"Settings"** (top tab).
2. In the left sidebar, click **"Pages"**.
3. Under **"Branch"**, select `main` and folder `/` (root).
4. Click **"Save"**.
5. Wait ~60 seconds, then refresh. A green banner will show:  
   **"Your site is published at `https://YOUR_USERNAME.github.io/YOUR_REPO/`"**

✅ Your website is now live!

---

## 📁 File Structure

```
lunovareprintz/
├── index.html      ← Main page (all sections)
├── style.css       ← All styles (design tokens, layout, responsive)
├── script.js       ← All JavaScript (navbar, FAQ, lightbox, form)
├── favicon.svg     ← Browser tab icon (LP monogram, orange + black)
└── README.md       ← This file
```

---

## ✏️ Customisation Guide

### Add Your Own Product Photos

In `index.html`, find any `product-thumb-ph` div inside a product card and replace it with an `<img>` tag:

```html
<!-- Before (placeholder) -->
<div class="product-thumb-ph">
  <i class="fas fa-tshirt"></i>
  <span>Add Product Image</span>
</div>

<!-- After (your real photo) -->
<img src="images/sports-jersey.webp"
     alt="Custom sports jersey Malaysia"
     style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0;">
```

Create an `images/` folder in the repo and upload your photos there.  
**Recommended image size:** 800 × 600 px, WebP format for best performance.

### Add Hero Image

In `index.html`, find the `hero-slash-img` div inside `#hero` and replace the icon with your jersey photo:

```html
<!-- Before -->
<div class="hero-slash-img">
  <i class="fas fa-tshirt"></i>
  <p>Add Hero Image Here</p>
</div>

<!-- After -->
<img src="images/hero-jersey.webp"
     alt="Custom sublimation jersey"
     style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0;">
```

**Recommended size:** 900 × 1100 px.

### Add Portfolio Photos (Gallery)

Replace the `gallery-ph` div inside each `.gallery-item` with a real image:

```html
<!-- Before -->
<div class="gallery-ph">
  <i class="fas fa-tshirt"></i>
  <span>Sports Jerseys</span>
</div>

<!-- After -->
<img src="images/portfolio-jersey.webp"
     alt="Custom sports jersey"
     style="width:100%;height:100%;object-fit:cover;">
```

### Add Social Media Links

Search `index.html` for `<!-- CUSTOMISE: Replace # with your actual social media URLs -->` and update the `href` values:

```html
<a href="https://instagram.com/lunovareprintz" ...>Instagram</a>
<a href="https://facebook.com/lunovareprintz"  ...>Facebook</a>
<a href="https://tiktok.com/@lunovareprintz"   ...>TikTok</a>
```

### Update Business Info

All contact details are already set. If anything changes, do a global find-and-replace in `index.html`:

| Find | Replace with |
|------|-------------|
| `60142479264` | Your new WhatsApp number |
| `lunovareprintz@gmail.com` | Your new email |

### Change Colours

All colours are CSS variables at the top of `style.css`:

```css
:root {
  --orange:        #FF5C00;   /* Primary brand colour */
  --orange-bright: #FF7A2E;   /* Hover state */
  --black:         #080808;   /* Page background */
  /* ... */
}
```

Change `--orange` to any hex code to instantly retheme the entire site.

---

## 🔗 WhatsApp Link Format

All buttons on this site use this WhatsApp deep link:

```
https://wa.me/60142479264?text=Hi%20Lunovar%C3%A9%20Printz%2C%20I%20would%20like%20to%20get%20a%20quotation.
```

- `60142479264` = country code (60) + number without leading zero
- `text=...` = pre-filled message (URL-encoded)

The contact form in `script.js` builds a richer message using the customer's form inputs.

---

## 🌐 Custom Domain (Optional)

To use `www.lunovareprintz.com` instead of the GitHub Pages URL:

1. Buy a domain from any registrar (Namecheap, GoDaddy, etc.).
2. In GitHub Pages settings, enter your domain under **"Custom domain"**.
3. At your domain registrar, add a **CNAME** record:
   - Host: `www`
   - Value: `YOUR_USERNAME.github.io`
4. Wait up to 24 hours for DNS to propagate.
5. Tick **"Enforce HTTPS"** in GitHub Pages settings.

---

## ⚡ Performance Notes

- **No build step** — files are served as-is by GitHub Pages.
- **Google Fonts** and **Font Awesome** load from CDN with `preconnect` for speed.
- **script.js** uses `defer` — it never blocks page rendering.
- **IntersectionObserver** powers scroll animations with zero layout thrash.
- **Parallax** is disabled automatically if the user has `prefers-reduced-motion` set.

---

## 📞 Business Contact

| Channel | Details |
|---------|---------|
| WhatsApp | [+60 14-247 9264](https://wa.me/60142479264) |
| Email | lunovareprintz@gmail.com |
| Coverage | Nationwide — Peninsular Malaysia, Sabah & Sarawak |

---

*Built for Lunovaré Printz · Malaysia's Premium Custom Sublimation Printing Specialist*
